<?php
$conexion = mysql_connect("localhost","emicapac_root","B@surto91");
mysql_select_db("emicapac_autos");
?>